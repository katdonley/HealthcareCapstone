import "./Footer.css";

const Footer = () => {
  return (
    <footer>
      <p>Copyright © 2022</p>{" "}
    </footer>
  );
};

export default Footer;
